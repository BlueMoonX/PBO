import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Waktu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Waktu extends Actor
{
    private GreenfootImage imgl=new GreenfootImage(205,100);
    //private Waktu waktu = new Waktu();
    int waktu = 0;
    /**
     * Act - do whatever the score wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        setImage(new GreenfootImage("Waktu : " + waktu, 25, Color.BLUE, Color.BLACK));
    }
    
    public void addWaktu()
    {
        if(waktu==1000)
        {
            Greenfoot.stop();
            //setImage(new GreenfootImage("Score  : " + 10, 25, Color.GREEN, Color.BLACK));
        }else{
            waktu++;
        }
    }
}
