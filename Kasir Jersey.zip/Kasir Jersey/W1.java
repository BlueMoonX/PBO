import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
/**
 * Write a description of class W1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class W1 extends World
{
    public Data data;
    public Submit submit;
    public Qty qty;
    public Data total;
    /**
     * Constructor for objects of class W1.
     * 
     */
    public W1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 600, 1); 
        
        prepare();
    }
    
    public void prepare()
    {
        Kasir kasir = new Kasir();
        addObject(kasir, 820, 550);
        
        Reset reset = new Reset() ;
        addObject(reset, 680, 550);
        
        Brg1 brg1 = new Brg1();
        addObject(brg1, 100, 330);
        Brg2 brg2 = new Brg2();
        addObject(brg2, 290, 330);
        Brg3 brg3 = new Brg3();
        addObject(brg3, 480, 330);
        Brg4 brg4 = new Brg4();
        addObject(brg4, 100, 500);
        Brg5 brg5 = new Brg5();
        addObject(brg5, 290, 500);
        Brg6 brg6 = new Brg6();
        addObject(brg6, 480, 500);
        
        data = new Data();
        addObject(data,200,130);
        submit = new Submit();
        addObject(submit, 525, 168);
        qty = new Qty();
        addObject(qty, 325,168);
        Plus plus = new Plus();
        addObject(plus, 425,168);
        //Min min = new Min();
        //addObject(min, 425,85);
        total = new Data();
        addObject(total,750,350);
        total.warna=Color.white;
        
        GreenfootImage image = getBackground();
        Color color = new Color (50, 250, 255, 70);
   
        image.setColor(java.awt.Color.BLACK);
        image.drawRect(10, 40, 600, 180);
        image.setColor(color);
        image.fillRect(10, 40, 600, 180);
        
        GreenfootImage images = getBackground();
        Color colors = new Color (50, 250, 255, 50);
        
        image.setColor(java.awt.Color.BLACK);
        image.drawRect(620, 40, 270, 430);
        images.setColor(colors);
        images.fillRect(620, 40, 270, 430);

        
    }    
    
    public Data getData(){return data;}
    public Qty getQty(){return qty;}
    public Data getTotal(){return total;}
}
