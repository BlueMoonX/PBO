import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
/**
 * Write a description of class Qty here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Qty extends Actor
{
    /**
     * Act - do whatever the Qty wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int qty=0;
    public void act() 
    {
        // Add your action code here.
        setImage(new GreenfootImage(qty+"",48,Color.yellow,Color.cyan));
    }    
    
    public void qtyPlus(){qty++;}
    public void qtyMin(){qty--;}
    public void reset(){qty=0;}
    public int getA(){return qty;}
}
