import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.*;
/**
 * Write a description of class Data here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Data extends Actor
{
    /**
     * Act - do whatever the Data wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private String print=" - ";
    private String nama;
    private int harga;
    private int idx=1;
    public int font_size=30;
    private int qty=0;
    private int ttl=0;
    public Color warna=Color.yellow;
    public void act() 
    {
        // Add your action code here.
        setImage(new GreenfootImage(print,font_size,warna,null));
        
    }    

    public void setPrint(String is,int ii)
    {
        print=is+"\n Rp "+ii; harga=ii; nama=is;
        World W=getWorld();
        ((W1)W).getQty().reset();
        ((W1)W).getQty().qtyPlus();
    }
    
    public void getA(){
        World W=getWorld();
        qty = ((W1)W).getQty().getA();
    }
    
    public void simpan(){
        getA();
        if(idx==1){
            Data data1 = new Data();
            getWorld().addObject(data1,750,100);
            data1.harga = harga*qty;
            data1.qty=qty;
            data1.nama = nama;
            data1.font_size=20;
            data1.print = data1.nama+" ("+qty+") "+data1.harga;
            ttl+=data1.harga;
        }
        if(idx==2){
            Data data2 = new Data();
            getWorld().addObject(data2,750,130);
            data2.harga = harga*qty;
            data2.nama = nama;
            data2.font_size=20;
            data2.print = data2.nama+" ("+qty+") "+data2.harga;
            ttl+=data2.harga;
        }
        if(idx==3){
            Data data3 = new Data();
            getWorld().addObject(data3,750,160);
            data3.harga = harga*qty;
            data3.nama = nama;
            data3.font_size=20;
            data3.print = data3.nama+" ("+qty+") "+data3.harga;
            ttl+=data3.harga;
        }
        if(idx==4){
            Data data4 = new Data();
            getWorld().addObject(data4,750,190);
            data4.harga = harga*qty;
            data4.nama = nama;
            data4.font_size=20;
            data4.print = data4.nama+" ("+qty+") "+data4.harga;
            ttl+=data4.harga;
        }
        if(idx==5){
            Data data5 = new Data();
            getWorld().addObject(data5,750,220);
            data5.harga = harga*qty;
            data5.nama = nama;
            data5.font_size=20;
            data5.print = data5.nama+" ("+qty+") "+data5.harga;
            ttl+=data5.harga;
        }
        if(idx==6){
            Data data6 = new Data();
            getWorld().addObject(data6,750,250);
            data6.harga = harga*qty;
            data6.nama = nama;
            data6.font_size=20;
            data6.print = data6.nama+" ("+qty+") "+data6.harga;
            ttl+=data6.harga;
        }
        World W=getWorld();
        ((W1)W).total.print = "TOTAL :\n"+ttl;
        idx++;
    }
}
