import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
import java.awt.Font;
/**
 * Write a description of class W2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class W2 extends World
{
    
    /**
     * Constructor for objects of class W2.
     * 
     */
    public W2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 600, 1); 
        
        prepare();
    }
    
    public void prepare()
    {
        Kembali kembali = new Kembali();
        addObject(kembali, 400, 550);
        
        GreenfootImage image = getBackground();
        Color color = new Color (80, 100, 150, 140);
   
        image.setColor(java.awt.Color.BLACK);
        image.drawRect(10, 40, 600, 180);
        image.setColor(color);
        image.fillRect(10, 40, 600, 180);
        
        GreenfootImage images = getBackground();
        Color colors = new Color (30, 50, 170, 100);
        
        image.setColor(java.awt.Color.BLACK);
        image.drawRect(620, 40, 270, 430);
        images.setColor(colors);
        images.fillRect(620, 40, 270, 430);
        
        Kalkulator1 kalkulator1 = new Kalkulator1();
        addObject(kalkulator1, 100, 250);
        Kalkulator2 kalkulator2 = new Kalkulator2();
        addObject(kalkulator2, 200, 250);
        Kalkulator3 kalkulator3 = new Kalkulator3();
        addObject(kalkulator3, 300, 250);
        Kalkulator4 kalkulator4 = new Kalkulator4();
        addObject(kalkulator4, 100, 350);
        Kalkulator5 kalkulator5 = new Kalkulator5();
        addObject(kalkulator5, 200, 350);
        Kalkulator6 kalkulator6 = new Kalkulator6();
        addObject(kalkulator6, 300, 350);
        
        Kalkulator7 kalkulator7 = new Kalkulator7();
        addObject(kalkulator7, 100, 450);
        Kalkulator8 kalkulator8 = new Kalkulator8();
        addObject(kalkulator8, 200, 450);
        Kalkulator9 kalkulator9 = new Kalkulator9();
        addObject(kalkulator9, 300, 450);
        Kalkulator0 kalkulator0 = new Kalkulator0();
        addObject(kalkulator0, 100, 550);
        Kalkulatorc kalkulatorc = new Kalkulatorc();
        addObject(kalkulatorc, 200, 550);
        Kalkulatorent kalkulatorent = new Kalkulatorent();
        addObject(kalkulatorent, 300, 550);
    }    
}
