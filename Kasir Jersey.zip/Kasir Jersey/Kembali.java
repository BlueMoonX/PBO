import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Kembali here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Kembali extends Actor
{
    /**
     * Act - do whatever the Kembali wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int w1;
    public void act() 
    {
        Kembali();
    }
    
    private void Kembali()
    {
        if (Greenfoot.mouseClicked(this))
        {
            Greenfoot.setWorld(new W1());
        }
    } 
}
