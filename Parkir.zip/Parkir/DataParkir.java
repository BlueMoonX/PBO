package Parkir;

import java.util.Date;
import java.util.Vector;

public class DataParkir {
	
	private static String cari;
	private static int count=0;
	private static int kapasitas=0;
	private static Vector<String> karcis=new Vector<String>();
	private static Vector<String> nopol=new Vector<String>();
	private static Vector<String> tgl=new Vector<String>();
	private static Vector<String> tgl2=new Vector<String>();
	private static Vector<Boolean> keluar=new Vector<Boolean>();
	
	//setter
	public static void setData(String plat){
		karcis.add("A"+(count+1));
		nopol.add(plat);
		tgl.add(new Date().toString());
		tgl2.add("");
		keluar.add(false);
		count++;
		kapasitas++;
	}
	
	//getter
	public static String getNopol(String k){
		String rNopol="";
		for(int i=0;i<karcis.size();i++){
			if(k.equalsIgnoreCase(karcis.elementAt(i)) && keluar.elementAt(i)==false){
				rNopol=nopol.elementAt(i);
				tgl2.setElementAt(new Date().toString(), i);
				keluar.setElementAt(true, i);
				kapasitas--;
			}
		}
		return rNopol;
	}
		
	public static String getKarcis(){
		return karcis.elementAt(count-1);
	}
	
	public static int getKapasitas(){
		return (2-kapasitas);
	}
	
	public static String cariData(String x){
		cari = "";
		for(int j=0;j<nopol.size();j++){
			if(x.equalsIgnoreCase(nopol.elementAt(j))){
				cari = "Informasi kendaraan nopol "+nopol.elementAt(j)+"\n"+
						"Kendaraan masuk pada : "+tgl.elementAt(j)+"\n"+
						"Dengan karcis : "+karcis.elementAt(j)+"\n";
				if(keluar.elementAt(j)==true){
					cari = cari+"Kendaraan keluar pada : "+tgl2.elementAt(j);
				}else{
					cari = cari+"kendaraan belum keluar";
				}
			}
		}
		if (cari.equalsIgnoreCase("")){
			cari = "Data tidak ditemukan";
		}
		return cari;
	}
}